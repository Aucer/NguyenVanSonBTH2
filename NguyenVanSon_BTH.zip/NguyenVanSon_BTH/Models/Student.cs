namespace NguyenVanSon_BTH.Models
{
    public class Student
    {
        //khai bao thuoc tinh cua doi tuong
        public int StudentID {get; set;}

        public string? StudentName {get; set;}

        public int Age {get; set;}
        
        public string StudentEmail { get; set; }
      
    }
}
