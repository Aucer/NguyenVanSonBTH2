namespace NguyenVanSon_BTH.Models
{
    public class Person
    {
        public int PersonAge { get; set; }
        public string? PersonAddress { get; set; }
        public string? PersonPhoneNumber { get; set;}
        public int PersonID { get; set; }
        public string? PersonName { get; set; }
    }
}