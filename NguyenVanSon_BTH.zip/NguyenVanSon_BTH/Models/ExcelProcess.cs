namespace NguyenVanSon_BTH.Models;

public class ExcelProcess
{
    // khai các phương thức/thuộc tính
    // khai báo 1 phương thức tổng 2 số

    public int SumTwoInt(int x, int y)
    {
        return x+y;
    }
}